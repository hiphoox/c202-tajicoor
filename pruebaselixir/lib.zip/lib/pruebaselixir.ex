defmodule Pruebaselixir do
  @moduledoc """
  Documentation for `Pruebaselixir`.
  """

  @doc """
  Modulo para manejar Pruebaselixir

  
  """


  def main(nombreArchivo) do
    Main.mainCompleto(nombreArchivo)
  end
end
